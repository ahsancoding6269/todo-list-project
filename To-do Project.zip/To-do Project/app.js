const addTodoBtn = document.getElementById("addTodoBtn")
const inputTag = document.getElementById("todoInput")
const todoListUl = document.getElementById("todoList")
const remaining = document.getElementById("itemsLeft") // ✅ matches your HTML
const clearCompletedBtn = document.getElementById("clearCompletedBtn")
const filterBtns = document.querySelectorAll(".filter-btn")
const date = document.getElementById("currentDate")

let todos = JSON.parse(localStorage.getItem("todos")) || []

// Update remaining count
const updateRemaining = () => {
    let left = todos.filter(item => !item.isCompleted).length;
    remaining.innerHTML = `${left} item${left !== 1 ? "s" : ""} left`;
}

// Populate todos in UI
const populateTodos = (filter = "all") => {
    let string = "";
    todos.forEach(todo => {
        if (
            filter === "all" ||
            (filter === "active" && !todo.isCompleted) ||
            (filter === "completed" && todo.isCompleted)
        ) {
            string += `
            <li id="${todo.id}" class="todo-item ${todo.isCompleted ? "completed" : ""}">
                <input type="checkbox" class="todo-checkbox" ${todo.isCompleted ? "checked" : ""}>
                <span class="todo-text">${todo.title}</span>
                <button class="delete-btn">×</button>
            </li>`
        }
    })
    todoListUl.innerHTML = string;

    // Toggle completion
    document.querySelectorAll(".todo-checkbox").forEach((checkbox) => {
        checkbox.addEventListener("change", (e) => {
            todos = todos.map(todo =>
                todo.id === e.target.parentNode.id
                    ? { ...todo, isCompleted: e.target.checked }
                    : todo
            )
            localStorage.setItem("todos", JSON.stringify(todos))
            updateRemaining()
            populateTodos(filter) // re-render
        })
    })

    // Delete todos
    document.querySelectorAll(".delete-btn").forEach((btn) => {
        btn.addEventListener("click", (e) => {
            if (confirm("Do you want to delete this todo?")) {
                todos = todos.filter(todo => todo.id !== e.target.parentNode.id)
                localStorage.setItem("todos", JSON.stringify(todos))
                updateRemaining()
                populateTodos(filter)
            }
        })
    })
}

// Add todo
addTodoBtn.addEventListener("click", () => {
    let todoText = inputTag.value.trim()
    if (todoText.length < 4) {
        alert("You cannot add a todo that small!")
        return
    }
    inputTag.value = ""
    let todo = {
        id: "todo-" + Date.now(),
        title: todoText,
        isCompleted: false
    }
    todos.push(todo)
    localStorage.setItem("todos", JSON.stringify(todos))
    updateRemaining()
    populateTodos()
})

// Add todo with Enter key
inputTag.addEventListener("keypress", (e) => {
    if (e.key === "Enter") addTodoBtn.click();
})

// Clear completed
clearCompletedBtn.addEventListener("click", () => {
    todos = todos.filter(todo => !todo.isCompleted)
    localStorage.setItem("todos", JSON.stringify(todos))
    updateRemaining()
    populateTodos()
})

// Filter buttons
filterBtns.forEach(btn => {
    btn.addEventListener("click", () => {
        document.querySelector(".filter-btn.active").classList.remove("active")
        btn.classList.add("active")
        populateTodos(btn.dataset.filter)
    })
})

// Show current date
date.innerHTML = new Date().toLocaleDateString();

// Initial load
updateRemaining()
populateTodos()
